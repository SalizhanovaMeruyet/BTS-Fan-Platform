package com.example.demo3;

import java.util.ArrayList;
import java.util.List;

public interface NotificationObserver {
    void notify(String message);
}
