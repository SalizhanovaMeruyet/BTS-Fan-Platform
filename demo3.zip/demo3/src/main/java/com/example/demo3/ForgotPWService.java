package com.example.demo3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class ForgotPWService implements PasswordRenewalService {

    private static final String USER_DATA_FILE = "user_data.txt";

    @Override
    public boolean renewPassword(String username, String newPassword) {
        try {
            List<String> userDataList = Files.readAllLines(Paths.get(USER_DATA_FILE));

            for (int i = 0; i < userDataList.size(); i++) {
                if (userDataList.get(i).contains("Username:" + username)) {
                    // Update the password with the new one
                    userDataList.set(i, "Username:" + username + ", Password:" + newPassword);

                    // Save the modified user data back to the file
                    Files.write(Paths.get(USER_DATA_FILE), userDataList);
                    return true;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }
}
