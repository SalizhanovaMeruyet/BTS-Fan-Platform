package com.example.demo3;

public interface SignUpObserver {
    void update(String message);
}
