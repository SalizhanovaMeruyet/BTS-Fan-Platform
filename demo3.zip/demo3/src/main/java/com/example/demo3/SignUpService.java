package com.example.demo3;

public interface SignUpService {
    void signUp(String username, String email, String password);

    void addObserver(SignUpObserver observer);

    void removeObserver(SignUpObserver observer);

    void notifyObservers(String message);
}

