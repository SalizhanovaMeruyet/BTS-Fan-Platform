package com.example.demo3;

import javafx.fxml.Initializable;

public class ArtistSugaControllerFactory implements ArtistPageControllerFactory {
    @Override
    public Initializable createArtistPageController() {
        return new ArtistSugaController();
    }

    @Override
    public Object call(Class<?> aClass) {
        return createArtistPageController();
    }
}
