package com.example.demo3;

import javafx.fxml.Initializable;

public class ArtistJinControllerFactory implements ArtistPageControllerFactory{
    public Initializable createArtistPageController() {
        return new ArtistJinController();
    }

    @Override
    public Object call(Class<?> aClass) {
        return createArtistPageController();
    }
}
