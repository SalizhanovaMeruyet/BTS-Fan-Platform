package com.example.demo3;

import javafx.fxml.Initializable;
import javafx.util.Callback;

public interface ArtistPageControllerFactory extends Callback<Class<?>, Object> {
    Initializable createArtistPageController();
}