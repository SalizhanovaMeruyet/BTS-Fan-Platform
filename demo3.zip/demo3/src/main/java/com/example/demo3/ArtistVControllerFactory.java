package com.example.demo3;

import javafx.fxml.Initializable;

public class ArtistVControllerFactory implements ArtistPageControllerFactory {
    @Override
    public Initializable createArtistPageController() {
        return new ArtistVController();
    }

    @Override
    public Object call(Class<?> aClass) {
        return createArtistPageController();
    }
}
