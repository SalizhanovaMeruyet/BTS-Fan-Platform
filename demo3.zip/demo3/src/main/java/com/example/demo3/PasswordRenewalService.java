package com.example.demo3;

public interface PasswordRenewalService {
    boolean renewPassword(String username, String newPassword);
}