package com.example.demo3;

public class SignInProxy implements SignInService {
    private SignInService signInService;

    @Override
    public boolean signIn(String username, String password) {
        System.out.println("Proxy: Performing additional checks before Sign In");

        if (signInService == null) {
            signInService = new SignInServiceImpl();
        }

        boolean result = signInService.signIn(username, password);

        System.out.println("Proxy: Performing additional actions after Sign In");

        return result;
    }
}
