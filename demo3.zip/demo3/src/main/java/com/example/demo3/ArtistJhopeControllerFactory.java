package com.example.demo3;

import javafx.fxml.Initializable;

public class ArtistJhopeControllerFactory implements ArtistPageControllerFactory {
    @Override
    public Initializable createArtistPageController() {
        return new ArtistJhopeController();
    }

    @Override
    public Object call(Class<?> aClass) {
        return createArtistPageController();
    }
}
