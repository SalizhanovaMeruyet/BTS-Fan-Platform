package com.example.demo3;

public class PasswordRenewalProxy implements PasswordRenewalService {

    private final PasswordRenewalService realService;

    public PasswordRenewalProxy(PasswordRenewalService realService) {
        this.realService = realService;
    }

    @Override
    public boolean renewPassword(String username, String newPassword) {
        System.out.println("Proxy: Logging password renewal for username " + username);

        boolean success = realService.renewPassword(username, newPassword);

        System.out.println("Proxy: Performing additional actions after password renewal");

        return success;
    }
}