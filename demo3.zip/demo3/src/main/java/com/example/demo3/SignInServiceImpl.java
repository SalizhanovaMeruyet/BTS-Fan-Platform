package com.example.demo3;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class SignInServiceImpl implements SignInService {
    private static final String USER_DATA_FILE = "user_data.txt";

    @Override
    public boolean signIn(String username, String password) {
        System.out.println("Performing Sign In");

        try {
            List<String> userDataList = Files.readAllLines(Paths.get(USER_DATA_FILE));

            for (String line : userDataList) {
                if (line.contains("Username:" + username) && line.contains("Password:" + password)) {
                    return true;
                }
            }
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}