package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class NotificationsController implements Initializable, NotificationObserver, SignUpObserver {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button buttonHome;

    @FXML
    private Pane pane;

    @FXML
    private Rectangle rectangle;

    @FXML
    private Label textNotification;

    @FXML
    private Circle writeCycle;

    private VBox activitiesVBox;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        NotificationService notificationService = new NotificationServiceImpl();
        SignUpService signUpService = new SignUpServiceImpl();

        notificationService.addObserver(this);

        signUpService.addObserver(this);

        buttonHome.setOnAction(actionEvent -> {
            buttonHome.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Home1.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
        activitiesVBox = new VBox();
        activitiesVBox.setLayoutX(10.0);
        activitiesVBox.setLayoutY(60.0);
        anchorPane.getChildren().add(activitiesVBox);

        fetchAndDisplayUpcomingActivities();
    }
    @Override
    public void notify(String message) {
        System.out.println("Received notification: " + message);
        showNotification(message);
    }
    private void showNotification(String message) {
        textNotification.setText(message);
    }
    private void fetchAndDisplayUpcomingActivities() {
        List<String> upcomingActivities = Arrays.asList("Jungkook VLive in 2 days", "V online concert next week", "RM talk show tomorrow", "Jhope dance practice today at 6pm");
        updateUpcomingActivities(upcomingActivities);
    }
    private void updateUpcomingActivities(List<String> activities) {
        activitiesVBox.getChildren().clear();
        for (String activity : activities) {
            Label activityLabel = new Label("Upcoming Activity: " + activity);
            activitiesVBox.getChildren().add(activityLabel);
        }
    }
    private void handleNewActivity(String newActivity) {
        System.out.println("New activity: " + newActivity);
        updateUpcomingActivities(Collections.singletonList(newActivity));
    }
    @Override
    public void update(String message) {
        System.out.println("Received update: " + message);
        handleNewActivity(message);
    }
}
