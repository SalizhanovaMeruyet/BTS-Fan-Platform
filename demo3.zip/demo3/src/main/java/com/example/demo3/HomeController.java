package com.example.demo3;

import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HomeController implements Initializable {

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private Button buttonJhope;

    @FXML
    private Button buttonJimin;

    @FXML
    private Button buttonJin;

    @FXML
    private Button buttonJungkook;

    @FXML
    private Button buttonLogOut;

    @FXML
    private Button buttonRM;

    @FXML
    private Button buttonSuga;

    @FXML
    private Button buttonV;

    @FXML
    private Button buttonNotification;


    @FXML
    private Pane pane;

    @FXML
    private Pane pane1;

    @FXML
    private ImageView photoBTS;

    @FXML
    private ImageView photoJhope;

    @FXML
    private ImageView photoJimin;

    @FXML
    private ImageView photoJin;

    @FXML
    private ImageView photoJungkook;

    @FXML
    private ImageView photoRM;

    @FXML
    private ImageView photoSuga;

    @FXML
    private ImageView photoV;

    @FXML
    private Rectangle rectangle;

    @FXML
    private Label textBTS;

    @FXML
    private Text textGreeting1;

    @FXML
    private Text textGreeting2;

    @FXML
    private Text textJhope;

    @FXML
    private Text textJimin;

    @FXML
    private Text textJin;

    @FXML
    private Text textJungkook;

    @FXML
    private Text textRM;

    @FXML
    private Label textSeven;

    @FXML
    private Text textSuga;

    @FXML
    private Text textV;

    @FXML
    private VBox vbox;

    private ArtistPageControllerFactory artistPageControllerFactory;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){

        buttonRM.setOnAction(event -> {
            switchArtistPageController(new ArtistRMControllerFactory(), "RM");
        });

        buttonJin.setOnAction(actionEvent -> {
            switchArtistPageController(new ArtistJinControllerFactory(), "Jin");
        });

        buttonSuga.setOnAction(actionEvent -> {
            switchArtistPageController(new ArtistSugaControllerFactory(), "Suga");
        });

        buttonJhope.setOnAction(actionEvent -> {
            switchArtistPageController(new ArtistJhopeControllerFactory(), "Jhope");
        });

        buttonJimin.setOnAction(actionEvent -> {
            switchArtistPageController(new ArtistJiminControllerFactory(), "Jimin");
        });

        buttonV.setOnAction(actionEvent -> {
            switchArtistPageController(new ArtistVControllerFactory(), "V");
        });

        buttonJungkook.setOnAction(actionEvent -> {
            buttonJungkook.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Jungkook.fxml"));

            try{
                loader.load();
            } catch (IOException e){
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

        buttonLogOut.setOnAction(actionEvent -> {

            buttonLogOut.getScene().getWindow().hide();

            saveRememberMeState(false);

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("SignIn.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

        });

        buttonNotification.setOnAction(actionEvent -> {
            buttonNotification.getScene().getWindow().hide();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Notifications.fxml"));

            try{
                loader.load();
            } catch (IOException e){
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });

    }
    private void switchArtistPageController(ArtistPageControllerFactory factory, String artist) {
        artistPageControllerFactory = factory;

        FXMLLoader loader = new FXMLLoader();
        String fxmlPath = String.format("%s.fxml", artist);
        loader.setLocation(getClass().getResource(fxmlPath));
        loader.setControllerFactory((Callback<Class<?>, Object>) artistPageControllerFactory);

        try {
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) anchorPane.getScene().getWindow();
            stage.setScene(scene);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveRememberMeState(boolean selected) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("remember_me_state.txt"))) {
            writer.write(selected ? "yes" : "no");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
