package com.example.demo3;

import java.util.ArrayList;
import java.util.List;

public class NotificationServiceImpl implements NotificationService {
    private List<NotificationObserver> observers = new ArrayList<>();

    @Override
    public void addObserver(NotificationObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(NotificationObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        for (NotificationObserver observer : observers) {
            observer.notify(message);
        }
    }
}