package com.example.demo3;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class SevenController {

    @FXML
    private Label seven;

    @FXML
    private Label textPlatform;

    public void initialize() {
        // Schedule a task to switch scenes after 5 seconds
        Timeline timeline = new Timeline(new KeyFrame(
                Duration.seconds(2),
                event -> switchToNextPage()));

        timeline.play();
    }

    // Utility method to switch to another page
    private void switchToNextPage() {
        try {
            Path filePath = Paths.get("remember_me_state.txt");
            if (Files.exists(filePath) && "yes".equalsIgnoreCase(Files.readString(filePath).trim())) {
                navigateToHomePage();
            } else {
                navigateToSignInPage();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void navigateToSignInPage() {
        seven.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("SignIn.fxml"));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void navigateToHomePage() {
        seven.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Home1.fxml"));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }


}
