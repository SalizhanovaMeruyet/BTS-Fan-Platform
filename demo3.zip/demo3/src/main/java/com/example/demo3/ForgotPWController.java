package com.example.demo3;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import java.io.IOException;

public class ForgotPWController{

    @FXML
    private Label Username;

    @FXML
    private Button buttonSend;

    @FXML
    private Button buttonSingUp;

    @FXML
    private Label textEnter;

    @FXML
    private TextField textFieldNewPW;

    @FXML
    private TextField textFieldUsername;

    @FXML
    private Label textForgotPW;

    @FXML
    private Label textHaveAcc;

    @FXML
    private Label textNewPW;

    private static final String USER_DATA_FILE = "user_data.txt";
    private PasswordRenewalService passwordRenewalService;

    public void initialize() {
        passwordRenewalService = new PasswordRenewalProxy(new ForgotPWService());

        buttonSend.setOnAction(event -> renewingPassword());

        buttonSingUp.setOnAction(event -> {
            System.out.println("Performing navigation to SignUp page");
            buttonSingUp.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("SignUp.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        });
    }
    public void renewingPassword(){
        System.out.println("Performing the change of password");
        if (textFieldUsername == null || textFieldNewPW == null) {
            System.err.println("Error: One or more fields are null");
            return;
        }
        String username = textFieldUsername.getText();
        String newPassword = textFieldNewPW.getText();

        if (username.isEmpty() || newPassword.isEmpty()) {
            showAlert("Error", "Empty Fields", "Please fill in all the fields.");
            return;
        }

        if (passwordRenewalService.renewPassword(username, newPassword)) {
            showAlert("Success", "Password Changed", "Password has been successfully changed.");
            navigateToNextPage();
        } else {
            showAlert("Error", "Username Not Found", "Username does not exist.");
        }
    }

    public void navigateToNextPage() {
        System.out.println("Performing the navigation to SignIn page");
        Stage stage = (Stage) buttonSend.getScene().getWindow();
        stage.close();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("SignIn.fxml"));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage signInStage = new Stage();
        signInStage.setScene(new Scene(root));
        signInStage.show();
    }


    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
