package com.example.demo3;

public interface SignInService {
    boolean signIn(String username, String password);
}

