package com.example.demo3;
import java.util.ArrayList;
import java.util.List;

public class SignUpProxy implements SignUpService {
    private SignUpService signUpService;
    private List<SignUpObserver> observers = new ArrayList<>();

    @Override
    public void signUp(String username, String email, String password) {
        System.out.println("Proxy: Performing additional checks before Sign Up");

        if (signUpService == null) {
            signUpService = new SignUpServiceImpl();
        }

        signUpService.signUp(username, email, password);

        notifyObservers("User signed up: " + username);

        System.out.println("Proxy: Performing additional actions after Sign Up");
    }

    @Override
    public void addObserver(SignUpObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(SignUpObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        for (SignUpObserver observer : observers) {
            observer.update(message);
        }
    }
}
