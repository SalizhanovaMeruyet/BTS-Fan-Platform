package com.example.demo3;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SignUpServiceImpl implements SignUpService {
    private static final String USER_DATA_FILE = "user_data.txt";

    private List<SignUpObserver> observers = new ArrayList<>();

    @Override
    public void signUp(String username, String email, String password) {
        System.out.println("Performing Sign Up");

        saveUserData(username, email, password);

        notifyObservers("User signed up: " + username);

    }

    @Override
    public void addObserver(SignUpObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(SignUpObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        for (SignUpObserver observer : observers) {
            observer.update(message);
        }
    }


    private void saveUserData(String username, String email, String password) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USER_DATA_FILE, true))) {
            writer.write("Username:" + username + ", Email:" + email + ", Password:" + password);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

