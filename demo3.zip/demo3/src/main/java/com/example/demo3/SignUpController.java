package com.example.demo3;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ResourceBundle;

public class SignUpController implements Initializable, SignUpObserver{

    @FXML
    private TextField buttonEmail;

    @FXML
    private PasswordField buttonPassword;

    @FXML
    private Button buttonSignUp;

    @FXML
    private Button buttonSignIn;

    @FXML
    private TextField buttonUsername;

    @FXML
    private Label textEmail;

    @FXML
    private Label textHaveAcc;

    @FXML
    private Label textPassword;

    @FXML
    private Label textSeven;

    @FXML
    private Label textSignUp;

    @FXML
    private Label textToContinue;

    @FXML
    private Label textUsername;

    @FXML
    private Label textWelcome;
    private SignUpService signUpService;
    private static final String USER_DATA_FILE = "user_data.txt";

    public void initialize(URL url, ResourceBundle resourceBundle) {
        signUpService = new SignUpProxy();
        signUpService.addObserver(this);
        buttonSignUp.setOnAction(actionEvent -> performSignUp());
        buttonSignIn.setOnAction(actionEvent -> switchToSignInScene());
    }

    public void update(String message) {
        System.out.println("Received notification: " + message);
    }

    public void performSignUp() {
        System.out.println("Performing Sign Up");

        if (buttonUsername == null || buttonEmail == null || buttonPassword == null) {
            System.err.println("Error: One or more fields are null");
            return;
        }

        String username = buttonUsername.getText();
        String email = buttonEmail.getText();
        String password = buttonPassword.getText();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Empty Fields", "Please fill in all the fields.");
            return;
        }

        if (password.length() != 8) {
            showAlert("Error", "Invalid Password", "Password must be exactly 8 characters long.");
            return;
        }

        if (isDuplicate(username, email)) {
            showAlert("Error", "Duplicate User", "Username or email already exists. Please choose a different one.");
            return;
        }

        signUpService.signUp(username, email, password);

        signUpService.notifyObservers("User signed up: " + username);

        switchScene("SignIn.fxml", buttonSignUp);
    }

    private void switchToSignInScene() {
        switchScene("SignIn.fxml", buttonSignIn);
    }

    private void switchScene(String scenePath, Button button) {
        button.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(scenePath));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private boolean isDuplicate(String username, String email) {
        try {
            return Files.lines(Paths.get(USER_DATA_FILE))
                    .anyMatch(line -> line.contains("Username:" + username) || line.contains("Email:" + email));
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
