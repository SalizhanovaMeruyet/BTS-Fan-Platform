package com.example.demo3;

import javafx.fxml.Initializable;

public class ArtistRMControllerFactory implements ArtistPageControllerFactory{
    public Initializable createArtistPageController() {
        return new ArtistRMController();
    }
    public Object call(Class<?> param) {
        return createArtistPageController();
    }
}
