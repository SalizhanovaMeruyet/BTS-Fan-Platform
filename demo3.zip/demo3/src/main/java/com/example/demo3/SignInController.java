package com.example.demo3;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.ResourceBundle;

public class SignInController implements Initializable{

    @FXML
    private Button buttonForgotPW;

    @FXML
    private PasswordField buttonPassword;

    @FXML
    private Button buttonSignUp;

    @FXML
    private Button buttonSignIn;

    @FXML
    private TextField buttonUsername;

    @FXML
    private CheckBox checkBoxRememberMe;

    @FXML
    private Label textHaveAcc;

    @FXML
    private Label textPassword;

    @FXML
    private Label textSeven;

    @FXML
    private Label textSignIn;

    @FXML
    private Label textToContinue;

    @FXML
    private Label textUsername;

    @FXML
    private Label textWelcome;
    private SignInService signInService;
    private static final String REMEMBER_ME_FILE = "remember_me_state.txt";

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        signInService = new SignInProxy();
        loadRememberMeState();

        buttonSignUp.setOnAction(actionEvent -> switchToSignUpScene());

        buttonSignIn.setOnAction(actionEvent -> handleSignIn());

        buttonForgotPW.setOnAction(actionEvent -> switchToForgotPWScene());
    }

    private void switchToSignUpScene() {
        switchScene("SignUp.fxml", buttonSignUp);
    }

    private void switchToForgotPWScene() {
        switchScene("ForgotPW.fxml", buttonForgotPW);
    }

    private void switchScene(String scenePath, Button button) {
        button.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(scenePath));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void handleSignIn() {
        System.out.println("Performing Sign In operation");

        if (buttonUsername == null || buttonPassword == null) {
            System.err.println("Error: One or more fields are null");
            return;
        }
        String username = buttonUsername.getText();
        String password = buttonPassword.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Empty Fields", "Please fill in all the fields.");
            return;
        }

        if (signInService.signIn(username, password)) {
            switchToHomeScene();
        } else {
            showAlert("Error", "Invalid Credentials", "Username or password is incorrect.");
        }

        saveRememberMeState();
    }

    private void switchToHomeScene() {
        switchScene("Home1.fxml", buttonSignIn);
    }

    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void loadRememberMeState() {
        try {
            Path filePath = Paths.get(REMEMBER_ME_FILE);
            if (Files.exists(filePath)) {
                String content = Files.readString(filePath);
                checkBoxRememberMe.setSelected("yes".equalsIgnoreCase(content.trim()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveRememberMeState() {
        try {
            Path filePath = Paths.get(REMEMBER_ME_FILE);
            Files.writeString(filePath, checkBoxRememberMe.isSelected() ? "yes" : "no");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
